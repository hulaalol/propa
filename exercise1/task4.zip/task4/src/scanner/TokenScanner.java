package scanner;

import java.util.*; 

public class TokenScanner {

    public static List<String> functionScanner(String input) {
        List<String> results = new ArrayList<>();

        return results;
    }

}
