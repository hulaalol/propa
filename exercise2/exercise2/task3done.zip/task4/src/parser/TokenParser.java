package parser;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class TokenParser {

	static String currentToken;
	static int tokenIndex = 0;
	static List<String> inputs;
	static Node currentNode;
	static Node tree;
	static int nodeId = 0;
	static boolean illegal = false;

	public static Node functionParser(List<String> input) {

		Node result = new Node(nodeId);
		nodeId++;
		result.setLabel("start");
		inputs = input;
		tree = result;
		currentNode = result;
		currentToken = input.get(tokenIndex);

		start(result);

		if (illegal) {
			Node fail = new Node(0);
			fail.setLabel("Illegal");
			return fail;
		} else {
			return result;
		}
	}

	public static String getNextToken() {
		tokenIndex++;

		try {
			currentToken = inputs.get(tokenIndex);
			return currentToken;
		} catch (Exception e) {
			illegal = true;
			return "Illegal";
		}
	}

	public static void start(Node n) {

		Node stmtList = new Node(nodeId++);
		stmtList.setLabel("stmt_list");
		n.addChildren(stmtList);
		stmt_list(stmtList);

		if (end()) {
			Node end = new Node(nodeId++);
			end.setLabel("$$");
			n.addChildren(end);
		} else {
			illegal = true;
			return;
		}

	}

	public static void stmt_list(Node n) {

		if (end()) {
			return;
		}

		if (illegal || currentToken.contentEquals("Illegal")) {
			illegal = true;
			return;
		}

		Node stmt = new Node(nodeId++);
		stmt.setLabel("stmt");
		n.addChildren(stmt);
		stmt(stmt);

		Node stmtList = new Node(nodeId++);
		stmtList.setLabel("stmt_list");
		n.addChildren(stmtList);
		stmt_list(stmtList);

	}

	public static void stmt(Node n) {

		if (id() && !isRead() && !isWrite()) {
			// match
			Node id = new Node(nodeId++);
			id.setLabel(currentToken);
			n.addChildren(id);

			currentToken = getNextToken();
			if (assignment()) {
				// match
				Node assign = new Node(nodeId++);
				assign.setLabel(":=");
				n.addChildren(assign);

				currentToken = getNextToken();

				Node expr = new Node(nodeId++);
				expr.setLabel("expr");
				n.addChildren(expr);
				expr(expr);
			}
		} else if (isRead()) {

			Node read = new Node(nodeId++);
			read.setLabel("read");
			n.addChildren(read);
			currentToken = getNextToken();

			id();
			Node id = new Node(nodeId++);
			id.setLabel(currentToken);
			n.addChildren(id);

		} else if (isWrite()) {

			Node write = new Node(nodeId++);
			write.setLabel("write");
			n.addChildren(write);

			currentToken = getNextToken();

			Node expr = new Node(nodeId++);
			expr.setLabel("expr");
			n.addChildren(expr);
			expr(expr);
		} else {
			illegal = true;
		}
	}

	public static void expr(Node n) {

		Node term = new Node(nodeId++);
		term.setLabel("term");
		n.addChildren(term);
		term(term);

		Node term_tail = new Node(nodeId++);
		term_tail.setLabel("term_tail");
		n.addChildren(term_tail);
		term_tail(term_tail);
	}

	public static void term(Node n) {

		Node factor = new Node(nodeId++);
		factor.setLabel("factor");
		n.addChildren(factor);
		factor(factor);

		Node factor_tail = new Node(nodeId++);
		factor_tail.setLabel("factor_tail");
		n.addChildren(factor_tail);
		factor_tail(factor_tail);
	}

	public static void term_tail(Node n) {

		if (match("+") || match("-")) {
			Node addop = new Node(nodeId++);
			addop.setLabel("add_op");
			n.addChildren(addop);
			add_op(addop);

			currentToken = getNextToken();
			term(n);
			term_tail(n);

		} else {
			// epsilon
		}
	}

	public static void factor(Node n) {

		if (match("(")) {

			Node par = new Node(nodeId++);
			par.setLabel("(");
			n.addChildren(par);

			Node expr = new Node(nodeId++);
			expr.setLabel("expr");
			n.addChildren(expr);
			expr(expr);

			if (match(")")) {
				Node par2 = new Node(nodeId++);
				par2.setLabel(")");
				n.addChildren(par2);

			}
		} else if (id()) {

			Node id = new Node(nodeId++);
			id.setLabel(currentToken);
			n.addChildren(id);
			currentToken = getNextToken();

		} else if (literal()) {

			Node lit = new Node(nodeId++);
			lit.setLabel(currentToken);
			n.addChildren(lit);
			currentToken = getNextToken();
		} else {
			illegal = true;
		}
	}

	public static void factor_tail(Node n) {

		if (match("*") || match("/")) {
			Node mult = new Node(nodeId++);
			mult.setLabel("mult_op");
			n.addChildren(mult);
			mult_op(mult);

			currentToken = getNextToken();
			Node factor = new Node(nodeId++);
			factor.setLabel("factor");
			n.addChildren(factor);
			factor(factor);

			Node factor_tail = new Node(nodeId++);
			factor_tail.setLabel("factor_tail");
			n.addChildren(factor_tail);
			factor_tail(factor_tail);

		} else {
			// epsilon?!?!?

		}

	}

	public static void add_op(Node n) {

		if (match("+")) {
			Node p = new Node(nodeId++);
			p.setLabel("+");
			n.addChildren(p);

		}
		if (match("-")) {
			Node m = new Node(nodeId++);
			m.setLabel("-");
			n.addChildren(m);
		}

	}

	public static void mult_op(Node n) {

		if (match("*")) {
			Node p = new Node(nodeId++);
			p.setLabel("*");
			n.addChildren(p);

		} else if (match("/")) {
			Node m = new Node(nodeId++);
			m.setLabel("/");
			n.addChildren(m);
		} else {
			illegal = true;
		}

	}

	public static boolean end() {
		if (currentToken.equals("$$")) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean id() {
		return Pattern.matches("[a-zA-Z]*", currentToken);
	}

	public static boolean literal() {
		return Pattern.matches("[0-9]+", currentToken);
	}

	public static boolean isRead() {
		return currentToken.equals("read");
	}

	public static boolean isWrite() {
		return currentToken.equals("write");
	}

	public static boolean assignment() {
		if (currentToken.equals(":=")) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean match(String token) {
		if (currentToken.equals(token)) {
			return true;
		} else {
			return false;
		}
	}

}
