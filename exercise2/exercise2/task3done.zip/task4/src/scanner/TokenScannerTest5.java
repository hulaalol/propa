package scanner;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class TokenScannerTest5 {

	// testing logical operators wtih and without whitespace
	@Test
	void test3() {
		List<String> list3 = Arrays.asList("while", "(","k", "!=", "0", ")","{", "ifreturn", 
        		"<=", "5897543889",";","test","<=","2","||","i","*","y","/","z","&&","true", "}");
        
		//TokenScanner test3 = new TokenScanner();
		List<String> results4 = TokenScanner.functionScanner("//if return while \n while (k!=0 ){\n ifreturn <= 5897543889; \n test <= 2 || i*y/z&&true} ");

		assertEquals(list3, results4);
	}

}
