package scanner;

import java.util.*; 

public class TokenScanner {

    public static List<String> functionScanner(String input) {
        List<String> results = new ArrayList<>();
        
        List<String> linesList = new ArrayList<String>();
        input.lines().forEach(line -> linesList.add(line));
        
        String[] lines = new String[linesList.size()];
        for(int i=0; i<linesList.size();i++) {
        	lines[i] = linesList.get(i);
        }
        
        for(String line : lines) {
            boolean match = false;

        	while(line.length()>0) {
        		
        		String currentToken = "";
        		int longestMatchLength = 0;
        		String longestMatch = "";

            	for(int i=0; i<line.length(); i++) {
          		
            		match = false;
            		currentToken+=line.charAt(i);
            		if(isWhitespace(currentToken)) {
            			line = line.substring(i+1, line.length());
            			break;
            		}
            		if(isPunctuator(currentToken)) {
            			results.add(currentToken);
            			line = line.substring(i+1, line.length());
            			break;
            		}
            		if(isKeyword(currentToken)) {
            			match=true;
            		}
            		if(isOp(currentToken)) {
            			match=true;
            		}
            		if(isComparison(currentToken)) {
            			match=true;
            		}

            		if(isAssign(currentToken)) {
            			match=true;
            		}
            		if(isComment(currentToken)) {
            			longestMatch = "";
            			longestMatchLength = 0;
            			line = "";
            			break;
            		}
            		if(isId(currentToken)) {
            			match=true;
            		}
            		if(match) {
            			longestMatchLength = currentToken.length();
            			longestMatch = currentToken;
            		}
            	}
            	if(line.length()>0) {
            		line = line.substring(longestMatchLength, line.length());
            	}
        		
        		if(longestMatch.length()>0) {
            		results.add(longestMatch);
        		}
        	}
        }
        return results;
    }
    
    public static boolean isKeyword(String s) {
    	String[] keywords = new String[] { "if", "else", "while", "for", "return" };
    	for(String kw: keywords) {
    		if(s.equals(kw)) {
    			return true;
    		}
    	}
    	return false;
    }
    

    public static boolean isOp(String s) {
    	String[] ops = new String[] { "+", "-", "*", "/","&&","||"};
    	for(String op: ops) {
    		if(s.equals(op)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    
    public static boolean isComparison(String s) {
    	String[] cmp = new String[] { "<", ">", "==", "!="};
    	for(String cp: cmp) {
    		if(s.equals(cp)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    public static boolean isAssign(String s) {
    	return s.equals("<=");
    }
    
    public static boolean isComment(String s) {
    	if(s.length()==2) {
        	return s.substring(0, 2).equals("//"); 	
    	}
    	return false;
    }
    
    public static boolean isId(String s) {
    if(s.matches("[a-zA-Z]*\\d*[a-zA-Z]*") && !isKeyword(s)) {
    	return true;
    }
    	return false;
    }
	
	public static boolean isPunctuator(String s) {
    	char c1 = s.charAt(0);
		char[] punctuators = new char[] {'(',')','[',']','{','}','.',';',','};
		for(char c2: punctuators) {
			if(c1 == c2) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isWhitespace(String s) {
    	for(int i=0; i<s.length();i++) {
    		if(!Character.isWhitespace(s.charAt(i))){
    			return false;
    		}
    	}
    	return true;
	}
}
