package scanner;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class TokenScannerTest6 {

	// test string assignment and multiple lines in while loop
	@Test
	void test3() {
		List<String> list3 = Arrays.asList("a", 
        		"<=", "stringAssignment",";","while", "(","k", "!=", "0", ")","{", "sum", 
        		"<=", "5897543889",";","return","2","*","sum", "}");
        
		//TokenScanner test3 = new TokenScanner();
		List<String> results4 = TokenScanner.functionScanner("a <=stringAssignment;//Simple loop \n while (k!=0 ){\n sum <= 5897543889; \n return 2*sum} ");

		assertEquals(list3, results4);
	}

}
