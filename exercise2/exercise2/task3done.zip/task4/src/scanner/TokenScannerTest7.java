package scanner;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class TokenScannerTest7 {

	// id right before comment without whitespace
	@Test
	void test3() {
		List<String> list3 = Arrays.asList("a", 
        		"<=", "stringAssignment",";","identifier","while", "(","k", "!=", "0", ")","{", "sum", 
        		"<=", "5897543889",";","return","2","*","sum", "}");
        
		//TokenScanner test3 = new TokenScanner();
		List<String> results4 = TokenScanner.functionScanner("a <=stringAssignment; identifier//Simple loop \n while (k!=0 ){\n sum <= 5897543889; \n return 2*sum} ");

		assertEquals(list3, results4);
	}

}

