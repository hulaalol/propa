package scanner;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class TokenScannerTest4 {

	// this test uses a variable which consists of 2 concatenated keywords
	@Test
	void test3() {
		List<String> list3 = Arrays.asList("while", "(","k", "!=", "0", ")","{", "ifreturn", 
        		"<=", "5897543889",";", "}");
        
		//TokenScanner test3 = new TokenScanner();
		List<String> results4 = TokenScanner.functionScanner("//Simple loop \n while (k!=0 ){\n ifreturn <= 5897543889;} ");

		assertEquals(list3, results4);
	}

}
