package parser;

import java.util.List;

public class TokenParser {
	public static Node functionParser(List<String> input) {
        Node result = new Node(0);

        return result;
    }
}
