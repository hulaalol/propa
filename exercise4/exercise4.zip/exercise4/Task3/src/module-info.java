module Task3 {
	requires org.junit.jupiter.api;
}